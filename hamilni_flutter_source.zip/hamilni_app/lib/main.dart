import 'package:flutter/material.dart';

void main() => runApp(const HamilniApp());

const brandGreen = Color(0xFF087F5B);

class HamilniApp extends StatelessWidget {
  const HamilniApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'حملني',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: brandGreen),
        scaffoldBackgroundColor: const Color(0xFFF6F8F7),
        appBarTheme: const AppBarTheme(backgroundColor: brandGreen, foregroundColor: Colors.white),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: HomePage()),
    );
  }
}

class TransportRequest {
  TransportRequest({required this.name, required this.phone, required this.from,
    required this.to, required this.load, required this.price});
  final String name, phone, from, to, load, price;
  String status = 'بانتظار سائق';
  String? driver;
}

class DemoStore extends ChangeNotifier {
  DemoStore._();
  static final DemoStore instance = DemoStore._();
  final List<TransportRequest> requests = [];
  void add(TransportRequest request) { requests.insert(0, request); notifyListeners(); }
  void accept(TransportRequest request, String driver) {
    request.status = 'تم قبول الطلب'; request.driver = driver; notifyListeners();
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  @override
  void initState() { super.initState(); DemoStore.instance.addListener(_refresh); }
  @override
  void dispose() { DemoStore.instance.removeListener(_refresh); super.dispose(); }
  void _refresh() { if (mounted) setState(() {}); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Row(children: [Icon(Icons.local_shipping_outlined), SizedBox(width: 10), Text('حملني', style: TextStyle(fontWeight: FontWeight.bold)), Spacer(), Text('الناصرية', style: TextStyle(fontSize: 14))])),
      body: IndexedStack(index: tab, children: const [CustomerPage(), DriverPage(), RequestsPage()]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.add_box_outlined), selectedIcon: Icon(Icons.add_box), label: 'اطلب نقل'),
          NavigationDestination(icon: Icon(Icons.drive_eta_outlined), selectedIcon: Icon(Icons.drive_eta), label: 'واجهة السائق'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'الطلبات'),
        ],
      ),
    );
  }
}

class CustomerPage extends StatelessWidget {
  const CustomerPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(18), children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: brandGreen, borderRadius: BorderRadius.circular(22)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('نقل حمولتك صار أسهل', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
        SizedBox(height: 8), Text('اطلب ستوت أو بيك أب أو شاحنة صغيرة داخل الناصرية.', style: TextStyle(color: Colors.white, height: 1.5)),
      ])),
      const SizedBox(height: 18),
      const Text('شنو تحتاج تنقل اليوم؟', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      _ServiceTile(icon: Icons.electric_rickshaw, title: 'ستوت', subtitle: 'للأغراض والحمولات الخفيفة', onTap: (c) => _openForm(c, 'ستوت')),
      _ServiceTile(icon: Icons.local_shipping_outlined, title: 'بيك أب', subtitle: 'للأثاث والأغراض المتوسطة', onTap: (c) => _openForm(c, 'بيك أب')),
      _ServiceTile(icon: Icons.fire_truck_outlined, title: 'شاحنة صغيرة', subtitle: 'للحمولات الأكبر والمحلات', onTap: (c) => _openForm(c, 'شاحنة صغيرة')),
      const SizedBox(height: 12),
      const Card(child: Padding(padding: EdgeInsets.all(14), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline, color: brandGreen), SizedBox(width: 10), Expanded(child: Text('هذه نسخة تجريبية. الطلبات محفوظة مؤقتاً داخل التطبيق على نفس الجهاز فقط.'))]))),
    ]);
  }
  static Future<void> _openForm(BuildContext context, String type) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => Directionality(textDirection: TextDirection.rtl, child: NewRequestPage(vehicle: type))));
  }
}

class _ServiceTile extends StatelessWidget {
  const _ServiceTile({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon; final String title, subtitle; final void Function(BuildContext) onTap;
  @override
  Widget build(BuildContext context) => Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(contentPadding: const EdgeInsets.all(12), leading: CircleAvatar(backgroundColor: const Color(0xFFE1F3EC), foregroundColor: brandGreen, child: Icon(icon)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_left), onTap: () => onTap(context)));
}

class NewRequestPage extends StatefulWidget {
  const NewRequestPage({super.key, required this.vehicle});
  final String vehicle;
  @override
  State<NewRequestPage> createState() => _NewRequestPageState();
}

class _NewRequestPageState extends State<NewRequestPage> {
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController(), phone = TextEditingController(), from = TextEditingController(), to = TextEditingController(), load = TextEditingController(), price = TextEditingController();
  @override
  void dispose() { name.dispose(); phone.dispose(); from.dispose(); to.dispose(); load.dispose(); price.dispose(); super.dispose(); }
  String? requiredText(String? v) => (v == null || v.trim().isEmpty) ? 'هذا الحقل مطلوب' : null;
  Widget field(String label, TextEditingController c, {TextInputType? type, String? Function(String?)? validator}) => Padding(padding: const EdgeInsets.only(bottom: 12), child: TextFormField(controller: c, keyboardType: type, validator: validator ?? requiredText, decoration: InputDecoration(labelText: label)));
  void submit() {
    if (!formKey.currentState!.validate()) return;
    DemoStore.instance.add(TransportRequest(name: name.text.trim(), phone: phone.text.trim(), from: from.text.trim(), to: to.text.trim(), load: '${widget.vehicle} — ${load.text.trim()}', price: price.text.trim()));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تسجيل الطلب في النسخة التجريبية')));
    Navigator.pop(context);
  }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text('طلب نقل — ${widget.vehicle}')), body: Form(key: formKey, child: ListView(padding: const EdgeInsets.all(18), children: [
    const Text('معلومات الطلب', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)), const SizedBox(height: 16),
    field('اسم الزبون', name), field('رقم الهاتف', phone, type: TextInputType.phone, validator: (v) => (v == null || v.trim().length < 7) ? 'أدخل رقم هاتف صحيحاً' : null),
    field('مكان التحميل / المنطقة', from), field('مكان التوصيل / المنطقة', to), field('شنو الحمولة؟', load), field('الأجرة المقترحة بالدينار العراقي', price, type: TextInputType.number),
    const SizedBox(height: 8), FilledButton.icon(onPressed: submit, icon: const Icon(Icons.check_circle_outline), label: const Padding(padding: EdgeInsets.all(13), child: Text('تأكيد طلب النقل'))),
  ])));
}

class DriverPage extends StatefulWidget { const DriverPage({super.key}); @override State<DriverPage> createState() => _DriverPageState(); }
class _DriverPageState extends State<DriverPage> {
  final driverName = TextEditingController(text: 'سائق حملني');
  @override
  void dispose() { driverName.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final store = DemoStore.instance;
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('أهلاً بالسائق', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 6), const Text('استعرض الطلبات التجريبية واضغط قبول إذا يناسبك.'), const SizedBox(height: 14),
      TextField(controller: driverName, decoration: const InputDecoration(labelText: 'اسم السائق الذي سيقبل الطلب')),
      const SizedBox(height: 12),
      if (store.requests.isEmpty) const _EmptyState(text: 'ماكو طلبات حالياً. جرّب تضيف طلب من تبويب «اطلب نقل».'),
      ...store.requests.map((r) => RequestCard(request: r, driverName: driverName.text, onChanged: () => setState(() {}))),
    ]);
  }
}

class RequestsPage extends StatelessWidget {
  const RequestsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final requests = DemoStore.instance.requests;
    if (requests.isEmpty) return const _EmptyState(text: 'لحد الآن ماكو طلبات نقل. أنشئ أول طلب من تبويب «اطلب نقل».');
    return ListView(padding: const EdgeInsets.all(16), children: [const Text('كل الطلبات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 12), ...requests.map((r) => RequestCard(request: r))]);
  }
}

class RequestCard extends StatelessWidget {
  const RequestCard({super.key, required this.request, this.driverName, this.onChanged});
  final TransportRequest request; final String? driverName; final VoidCallback? onChanged;
  @override
  Widget build(BuildContext context) => Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [const Icon(Icons.inventory_2_outlined, color: brandGreen), const SizedBox(width: 8), Expanded(child: Text(request.load, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold))), const SizedBox(width: 4), Chip(label: Text(request.status, style: const TextStyle(fontSize: 11)))]),
    const Divider(), _detail(Icons.person_outline, 'الزبون: ${request.name}'), _detail(Icons.phone_outlined, 'الهاتف: ${request.phone}'), _detail(Icons.trip_origin, 'من: ${request.from}'), _detail(Icons.location_on_outlined, 'إلى: ${request.to}'), _detail(Icons.payments_outlined, 'الأجرة: ${request.price} د.ع'),
    if (request.driver != null) _detail(Icons.drive_eta_outlined, 'السائق: ${request.driver}'),
    if (driverName != null && request.status == 'بانتظار سائق') ...[const SizedBox(height: 10), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () { DemoStore.instance.accept(request, driverName!.trim().isEmpty ? 'سائق حملني' : driverName!.trim()); onChanged?.call(); }, icon: const Icon(Icons.check), label: const Text('قبول الطلب')))],
  ])));
  Widget _detail(IconData icon, String text) => Padding(padding: const EdgeInsets.only(bottom: 7), child: Row(children: [Icon(icon, size: 18, color: Colors.black54), const SizedBox(width: 8), Expanded(child: Text(text))]));
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.text}); final String text;
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.inbox_outlined, size: 54, color: Colors.grey), const SizedBox(height: 14), Text(text, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54, height: 1.6))])));
}
